﻿namespace SIMS_Application.Models
{
    public class AdminModel
    {
        public string Name { get; set; }
        public AdminModel()
        {

        }

    }
}
